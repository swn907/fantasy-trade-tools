FANTASY TRADE TOOLS — READY-TO-HOST STATIC SITE

FILES
- index.html      Home screen
- analyzer.html   2-team / 3-team trade analyzer
- generator.html  Trade generator + league imports

QUICKEST HOSTING OPTION: NETLIFY DROP
1. Unzip this folder.
2. Go to https://app.netlify.com/drop
3. Drag the entire fantasy_trade_tools_site folder onto the page.
4. Netlify will create an https:// link.
5. Send that link to anyone. It should work normally on iPhone, Android, Mac, and PC.

OTHER OPTIONS
- GitHub Pages
- Cloudflare Pages
- Vercel

IMPORTANT
Opening these as file:// previews on iPhone can prevent or restrict JavaScript.
Use the hosted https:// version for normal mobile behavior.
